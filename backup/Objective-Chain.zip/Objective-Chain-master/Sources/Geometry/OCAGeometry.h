//
//  ObjectiveChain.h
//  Objective-Chain
//
//  Created by Martin Kiss on 30.12.13.
//  Copyright © 2014 Martin Kiss. All rights reserved.
//



#import "OCAGeometry+Functions.h"


#import "OCAGeometry+Functions.h"
#import "OCATransformer+CGPoint.h"
#import "OCATransformer+CGSize.h"
#import "OCATransformer+CGRect.h"
#import "OCATransformer+CGAffineTransform.h"
#import "OCATransformer+UIEdgeInsets.h"
#import "OCATransformer+CATransform3D.h"
//TODO: CGPath


#import "OCAPredicate+CGPoint.h"
#import "OCAPredicate+CGSize.h"
#import "OCAPredicate+CGRect.h"
#import "OCAPredicate+CGAffineTransform.h"
#import "OCAPredicate+UIEdgeInsets.h"
#import "OCAPredicate+CATransform3D.h"


