//
//  CAEThrottledExample.h
//  Chain Examples
//
//  Created by Martin Kiss on 10.3.14.
//  Copyright (c) 2014 iMartin Kiss. All rights reserved.
//

#import "CAEExampleViewController.h"

@interface CAEThrottledExample : CAEExampleViewController

@end
